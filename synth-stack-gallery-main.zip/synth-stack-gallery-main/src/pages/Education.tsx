import { GraduationCap, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';

const education = [
  {
    title: 'Tecnicatura en Programación',
    institution: 'Universidad / Instituto',
    period: '2020 — Presente',
    desc: 'Formación en desarrollo de software, bases de datos, algoritmos y arquitectura de sistemas.',
  },
];

const Education = () => (
  <div className="min-h-screen">
    <Navbar />
    <section className="pt-24 pb-20">
      <div className="container mx-auto px-4 max-w-3xl">
        <Link to="/" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors mb-8 font-mono">
          <ArrowLeft size={12} /> cd ~/home
        </Link>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center">
            <GraduationCap size={16} className="text-primary" />
          </div>
          <div>
            <p className="text-primary font-mono text-[10px] tracking-widest uppercase neon-text">~/education</p>
            <h1 className="text-2xl font-bold font-sans tracking-tight">Formación profesional</h1>
          </div>
        </div>

        <div className="space-y-4">
          {education.map((edu, i) => (
            <div key={i} className="glass rounded p-5 card-hover animate-fade-up" style={{ animationDelay: `${i * 0.1}s` }}>
              <h3 className="font-semibold font-sans text-sm mb-1">{edu.title}</h3>
              <p className="text-xs text-primary/70 mb-1 font-mono">{edu.institution}</p>
              <p className="text-[10px] text-accent font-mono amber-glow mb-3">{edu.period}</p>
              <p className="text-sm text-muted-foreground leading-relaxed">{edu.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default Education;
