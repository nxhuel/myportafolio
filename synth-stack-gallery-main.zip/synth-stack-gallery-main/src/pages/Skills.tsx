import { Code2, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/Navbar';

const skills = [
  { category: 'Backend', items: ['Java', 'Spring Boot', 'Python', 'Node.js'] },
  { category: 'Frontend', items: ['React', 'TypeScript', 'Tailwind CSS'] },
  { category: 'Databases', items: ['PostgreSQL', 'MySQL', 'MongoDB', 'Redis'] },
  { category: 'DevOps', items: ['Docker', 'GitHub Actions', 'Linux', 'AWS'] },
  { category: 'Tools', items: ['Git', 'Postman', 'IntelliJ', 'VS Code'] },
];

const Skills = () => (
  <div className="min-h-screen">
    <Navbar />
    <section className="pt-24 pb-20">
      <div className="container mx-auto px-4 max-w-3xl">
        <Link to="/" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary transition-colors mb-8 font-mono">
          <ArrowLeft size={12} /> cd ~/home
        </Link>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center">
            <Code2 size={16} className="text-primary" />
          </div>
          <div>
            <p className="text-primary font-mono text-[10px] tracking-widest uppercase neon-text">~/skills</p>
            <h1 className="text-2xl font-bold font-sans tracking-tight">Habilidades técnicas</h1>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {skills.map((cat, i) => (
            <div key={cat.category} className="glass rounded p-4 card-hover animate-fade-up" style={{ animationDelay: `${i * 0.08}s` }}>
              <h3 className="text-xs font-semibold text-primary mb-3 font-mono tracking-wide">$ {cat.category.toLowerCase()}</h3>
              <div className="flex flex-wrap gap-1.5">
                {cat.items.map(item => (
                  <span key={item} className="text-[11px] px-2 py-1 rounded bg-primary/8 text-foreground border border-primary/15 font-mono">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default Skills;
