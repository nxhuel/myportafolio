import { useState, useMemo } from 'react';
import { Search, FileText, Github, X, ChevronLeft, ChevronRight, Eye } from 'lucide-react';

type ProjectStatus = 'active' | 'in-progress' | 'done';
type ProjectType = 'API' | 'Web' | 'Automatización';

interface Project {
  name: string;
  description: string;
  techs: string[];
  status: ProjectStatus;
  type: ProjectType;
  github?: string;
  docs?: string;
  images: string[];
}

const projects: Project[] = [
  {
    name: 'Auth Service',
    description: 'Microservicio de autenticación con JWT, OAuth2 y gestión de sesiones seguras.',
    techs: ['Java', 'Spring Boot', 'PostgreSQL', 'Redis'],
    status: 'active',
    type: 'API',
    github: '#',
    docs: 'https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf',
    images: [
      'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&h=500&fit=crop',
      'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&h=500&fit=crop',
      'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&h=500&fit=crop',
    ],
  },
  {
    name: 'Data Pipeline',
    description: 'Pipeline ETL automatizado para procesamiento de datos en tiempo real.',
    techs: ['Python', 'Apache Kafka', 'Docker'],
    status: 'active',
    type: 'Automatización',
    github: '#',
    images: [
      'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&h=500&fit=crop',
      'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=500&fit=crop',
    ],
  },
  {
    name: 'E-commerce API',
    description: 'API REST completa para plataforma de comercio electrónico con pagos integrados.',
    techs: ['Java', 'Spring Boot', 'MySQL', 'Stripe'],
    status: 'done',
    type: 'API',
    github: '#',
    docs: 'https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf',
    images: [
      'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&h=500&fit=crop',
      'https://images.unsplash.com/photo-1563986768609-322da13575f2?w=800&h=500&fit=crop',
    ],
  },
  {
    name: 'Admin Dashboard',
    description: 'Panel de administración con métricas en tiempo real y gestión de usuarios.',
    techs: ['React', 'TypeScript', 'Tailwind', 'Recharts'],
    status: 'in-progress',
    type: 'Web',
    github: '#',
    images: [
      'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=500&fit=crop',
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&h=500&fit=crop',
    ],
  },
  {
    name: 'CI/CD Automator',
    description: 'Herramienta CLI para automatizar pipelines de deployment multi-entorno.',
    techs: ['Python', 'Docker', 'GitHub Actions'],
    status: 'active',
    type: 'Automatización',
    github: '#',
    docs: 'https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf',
    images: [
      'https://images.unsplash.com/photo-1618401471353-b98afee0b2eb?w=800&h=500&fit=crop',
      'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&h=500&fit=crop',
    ],
  },
  {
    name: 'Notification Hub',
    description: 'Sistema centralizado de notificaciones push, email y SMS.',
    techs: ['Java', 'Spring', 'RabbitMQ', 'MongoDB'],
    status: 'done',
    type: 'API',
    github: '#',
    images: [
      'https://images.unsplash.com/photo-1563986768609-322da13575f2?w=800&h=500&fit=crop',
      'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&h=500&fit=crop',
    ],
  },
];

const allTechs = [...new Set(projects.flatMap(p => p.techs))].sort();
const allTypes: ProjectType[] = ['API', 'Web', 'Automatización'];
const allStatuses: { value: ProjectStatus; label: string }[] = [
  { value: 'active', label: 'Activo' },
  { value: 'in-progress', label: 'En progreso' },
  { value: 'done', label: 'Finalizado' },
];

const statusConfig: Record<ProjectStatus, { class: string; label: string }> = {
  active: { class: 'status-active', label: 'Activo' },
  'in-progress': { class: 'status-progress', label: 'En progreso' },
  done: { class: 'status-done', label: 'Finalizado' },
};

const ProjectPortal = () => {
  const [search, setSearch] = useState('');
  const [filterTech, setFilterTech] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [docModal, setDocModal] = useState<{ name: string; url: string } | null>(null);
  const [showcase, setShowcase] = useState<Project | null>(null);
  const [imgIndex, setImgIndex] = useState(0);

  const filtered = useMemo(() => {
    return projects.filter(p => {
      if (search && !p.name.toLowerCase().includes(search.toLowerCase())) return false;
      if (filterTech && !p.techs.includes(filterTech)) return false;
      if (filterType && p.type !== filterType) return false;
      if (filterStatus && p.status !== filterStatus) return false;
      return true;
    });
  }, [search, filterTech, filterType, filterStatus]);

  const openShowcase = (project: Project) => {
    setShowcase(project);
    setImgIndex(0);
  };

  return (
    <section id="projects" className="py-32">
      <div className="max-w-7xl mx-auto px-6 sm:px-10">
        <div className="mb-16 text-center">
          <p className="text-primary font-mono text-sm tracking-widest uppercase mb-4 neon-text">~/projects</p>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold font-sans tracking-tight">
            Portal de <span className="text-primary">Proyectos</span>
          </h2>
        </div>

        {/* Filters */}
        <div className="max-w-6xl mx-auto mb-12 space-y-5">
          <div className="relative max-w-md mx-auto">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Buscar proyecto..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-11 pr-5 py-3 rounded-lg bg-secondary border border-border text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:border-primary/40 transition-colors"
            />
          </div>

          <div className="flex flex-wrap justify-center gap-3">
            <select
              value={filterTech}
              onChange={e => setFilterTech(e.target.value)}
              className="px-4 py-2 rounded-lg bg-secondary border border-border text-sm text-foreground focus:outline-none focus:border-primary/40"
            >
              <option value="">Tecnología</option>
              {allTechs.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
            <select
              value={filterType}
              onChange={e => setFilterType(e.target.value)}
              className="px-4 py-2 rounded-lg bg-secondary border border-border text-sm text-foreground focus:outline-none focus:border-primary/40"
            >
              <option value="">Tipo</option>
              {allTypes.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
            <select
              value={filterStatus}
              onChange={e => setFilterStatus(e.target.value)}
              className="px-4 py-2 rounded-lg bg-secondary border border-border text-sm text-foreground focus:outline-none focus:border-primary/40"
            >
              <option value="">Estado</option>
              {allStatuses.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
            {(filterTech || filterType || filterStatus) && (
              <button
                onClick={() => { setFilterTech(''); setFilterType(''); setFilterStatus(''); }}
                className="px-4 py-2 rounded-lg text-sm text-primary hover:bg-primary/10 transition-colors font-mono"
              >
                Limpiar
              </button>
            )}
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {filtered.map((project, i) => (
            <div
              key={project.name}
              className="glass rounded-xl overflow-hidden card-hover group animate-fade-up cursor-pointer"
              style={{ animationDelay: `${i * 0.08}s` }}
              onClick={() => openShowcase(project)}
            >
              <div className="relative overflow-hidden h-48">
                <img
                  src={project.images[0]}
                  alt={project.name}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 opacity-80"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />
                <span className={`absolute top-3 right-3 text-xs px-2.5 py-1 rounded border font-mono ${statusConfig[project.status].class}`}>
                  {statusConfig[project.status].label}
                </span>
                <div className="absolute bottom-3 right-3 flex items-center gap-1.5 text-xs text-muted-foreground font-mono opacity-0 group-hover:opacity-100 transition-opacity">
                  <Eye size={14} /> Ver proyecto
                </div>
              </div>

              <div className="p-6">
                <h3 className="font-semibold font-sans text-lg mb-2 group-hover:text-primary transition-colors">{project.name}</h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2 leading-relaxed">{project.description}</p>

                <div className="flex flex-wrap gap-1.5 mb-4">
                  {project.techs.map(t => (
                    <span key={t} className="text-xs px-2 py-0.5 rounded bg-primary/8 text-primary/80 border border-primary/15 font-mono">
                      {t}
                    </span>
                  ))}
                </div>

                <div className="flex gap-2">
                  {project.github && (
                    <a
                      href={project.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={e => e.stopPropagation()}
                      className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-secondary hover:bg-primary/10 hover:text-primary transition-colors font-mono"
                    >
                      <Github size={14} /> GitHub
                    </a>
                  )}
                  {project.docs && (
                    <button
                      onClick={e => { e.stopPropagation(); setDocModal({ name: project.name, url: project.docs! }); }}
                      className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-secondary hover:bg-primary/10 hover:text-primary transition-colors font-mono"
                    >
                      <FileText size={14} /> Docs
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="py-20 text-center text-muted-foreground">
            <p className="font-mono text-sm">$ query returned 0 results</p>
          </div>
        )}
      </div>

      {/* Project Showcase Modal */}
      {showcase && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8"
          onClick={() => setShowcase(null)}
        >
          <div className="absolute inset-0 bg-background/85 backdrop-blur-xl" />
          <div
            className="relative z-10 w-full max-w-5xl glass rounded-2xl border border-primary/20 overflow-hidden animate-fade-up"
            onClick={e => e.stopPropagation()}
          >
            {/* Image carousel */}
            <div className="relative h-64 sm:h-80 md:h-96 bg-background/50">
              <img
                src={showcase.images[imgIndex]}
                alt={`${showcase.name} - ${imgIndex + 1}`}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card/80 via-transparent to-card/30" />

              {showcase.images.length > 1 && (
                <>
                  <button
                    onClick={() => setImgIndex(i => (i - 1 + showcase.images.length) % showcase.images.length)}
                    className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full glass flex items-center justify-center text-foreground hover:text-primary transition-colors"
                  >
                    <ChevronLeft size={20} />
                  </button>
                  <button
                    onClick={() => setImgIndex(i => (i + 1) % showcase.images.length)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full glass flex items-center justify-center text-foreground hover:text-primary transition-colors"
                  >
                    <ChevronRight size={20} />
                  </button>
                </>
              )}

              {/* Dots */}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                {showcase.images.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setImgIndex(i)}
                    className={`w-2 h-2 rounded-full transition-all ${i === imgIndex ? 'bg-primary w-6' : 'bg-foreground/30 hover:bg-foreground/50'}`}
                  />
                ))}
              </div>

              <button
                onClick={() => setShowcase(null)}
                className="absolute top-4 right-4 w-10 h-10 rounded-full glass flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
              >
                <X size={18} />
              </button>

              <span className={`absolute top-4 left-4 text-xs px-3 py-1 rounded border font-mono ${statusConfig[showcase.status].class}`}>
                {statusConfig[showcase.status].label}
              </span>
            </div>

            {/* Info */}
            <div className="p-8 sm:p-10">
              <h3 className="text-2xl sm:text-3xl font-bold font-sans mb-3">{showcase.name}</h3>
              <p className="text-base text-muted-foreground mb-6 leading-relaxed max-w-3xl">{showcase.description}</p>

              <div className="flex flex-wrap gap-2 mb-8">
                {showcase.techs.map(t => (
                  <span key={t} className="text-sm px-3 py-1 rounded-lg bg-primary/8 text-primary/80 border border-primary/15 font-mono">
                    {t}
                  </span>
                ))}
              </div>

              <div className="flex flex-wrap gap-3">
                {showcase.github && (
                  <a
                    href={showcase.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm px-5 py-2.5 rounded-lg bg-secondary hover:bg-primary/10 hover:text-primary transition-colors font-mono"
                  >
                    <Github size={16} /> Ver en GitHub
                  </a>
                )}
                {showcase.docs && (
                  <button
                    onClick={() => { setShowcase(null); setDocModal({ name: showcase.name, url: showcase.docs! }); }}
                    className="flex items-center gap-2 text-sm px-5 py-2.5 rounded-lg bg-secondary hover:bg-primary/10 hover:text-primary transition-colors font-mono"
                  >
                    <FileText size={16} /> Documentación
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PDF Modal */}
      {docModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          onClick={() => setDocModal(null)}
        >
          <div className="absolute inset-0 bg-background/85 backdrop-blur-xl" />
          <div
            className="relative z-10 w-full max-w-5xl h-[85vh] glass rounded-2xl border border-primary/20 flex flex-col overflow-hidden animate-fade-up"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <div className="flex items-center gap-3">
                <FileText size={18} className="text-primary" />
                <span className="text-base font-mono text-foreground">{docModal.name}</span>
                <span className="text-xs text-muted-foreground font-mono">— documentación</span>
              </div>
              <button
                onClick={() => setDocModal(null)}
                className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
              >
                <X size={18} />
              </button>
            </div>
            <div className="flex-1 overflow-auto bg-background/50">
              <iframe
                src={docModal.url}
                title={`Documentación - ${docModal.name}`}
                className="w-full h-full border-0"
              />
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default ProjectPortal;
